## JWT Authentication
<img src="images/jwt-authentication.png" width="100%" />