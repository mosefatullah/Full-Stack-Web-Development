## OAuth - Open Authentication
<img src="images/oauth.png" width="100%" />