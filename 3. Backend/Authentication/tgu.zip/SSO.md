## SSO - Single Sign On
<img src="images/sso.png" width="100%" />