## Basic Authentication
<img src="images/basic-authentication.png" width="100%" />