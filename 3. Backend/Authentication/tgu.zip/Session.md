## Session Based Authentication
<img src="images/session-authentication.png" width="100%" />