## Token Based Authentication
<img src="images/token-authentication.png" width="100%" />